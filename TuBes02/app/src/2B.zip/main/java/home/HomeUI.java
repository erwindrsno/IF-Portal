package home;

public interface HomeUI {
    void hideView();
    void hideMenu();
}
