package pengumuman;

import java.util.ArrayList;

import pengumuman.model.Pengumuman;

public interface ListPengumumanUI {
    void updateList(ArrayList<Pengumuman> daftarPengumuman);
    void updateDialogView(Pengumuman pengumuman);
}