package pengumuman;

public class DetailPengumumanFragment {
}
