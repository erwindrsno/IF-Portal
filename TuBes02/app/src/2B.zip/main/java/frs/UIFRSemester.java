package frs;

import java.util.ArrayList;

public interface UIFRSemester {
    void updateListSemester(ArrayList<Integer> semester);
}
