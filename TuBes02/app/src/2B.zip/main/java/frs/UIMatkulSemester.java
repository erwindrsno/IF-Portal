package frs;

import java.util.ArrayList;

public interface UIMatkulSemester {
    void updateListMatkul(ArrayList<MataKuliah> matkuls);
}
