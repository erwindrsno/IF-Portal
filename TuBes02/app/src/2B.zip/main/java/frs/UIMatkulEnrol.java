package frs;

import java.util.ArrayList;

public interface UIMatkulEnrol {
    void updateListMatkulE(ArrayList<MataKuliahEnrol> matkulE);
}
